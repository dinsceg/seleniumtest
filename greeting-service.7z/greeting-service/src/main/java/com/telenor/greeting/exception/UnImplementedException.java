package com.telenor.greeting.exception;

public class UnImplementedException extends RuntimeException {
    public UnImplementedException(String message) {
        super(message);
    }
}
