package com.telenor.greeting.resources;

import com.telenor.greeting.model.Account;
import com.telenor.greeting.model.Type;
import com.telenor.greeting.service.GreetingService;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;

import javax.validation.constraints.Min;
import java.util.Arrays;
import java.util.Objects;

@RestController
@RequestMapping("/greeting")
@AllArgsConstructor
public class GreetingController {

    private final GreetingService service;

    @GetMapping("/")
    @ApiOperation("Get the greeting phrase")
    public Mono<String> greeting(@RequestParam(required = false) @Min(1) Integer id,
                                 @RequestParam @ApiParam(value = "Account", required = true, allowableValues = "private,business", defaultValue = "private")
                                         String account,
                                 @RequestParam(required = false) @ApiParam(value = "Type", required = false, allowableValues = "small,big", defaultValue = "big")
                                         String type) {

        validateRequest(id, account, type);

        return service.greeting(id, account, type);
    }

    private void validateRequest(Integer id, String account, String type) {
        if ((Objects.nonNull(id) && id < 0) ||
                !Arrays.asList(Account.values()).contains(Account.valueOf(account.toUpperCase())) ||
                (Objects.nonNull(type) && !Arrays.asList(Type.values()).contains(Type.valueOf(type.toUpperCase()))) ||
                (Objects.isNull(id) && Objects.isNull(type))) {
            throw new IllegalArgumentException("invalid request");
        }
    }

}
