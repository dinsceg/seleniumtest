package com.telenor.greeting.service;


import com.telenor.greeting.exception.UnImplementedException;
import com.telenor.greeting.model.Account;
import com.telenor.greeting.model.Type;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.util.Objects;

import static com.telenor.greeting.model.Account.BUSINESS;
import static com.telenor.greeting.model.Account.PERSONAL;
import static com.telenor.greeting.model.Type.BIG;
import static com.telenor.greeting.model.Type.SMALL;

@Service
public class GreetingService {

    public Mono<String> greeting(Integer userId, String account, String type) {

        String greeting = "";

        if (Objects.nonNull(type) && SMALL == Type.fromString(type) && BUSINESS == Account.fromString(account)) {
            throw new UnImplementedException("path is not implemented");
        }

        if (Objects.nonNull(userId) && PERSONAL == Account.fromString(account)) {
            greeting = "Hi, userId ".concat(String.valueOf(userId));
        }

        if (Objects.nonNull(type) && BIG == Type.fromString(type) && BUSINESS == Account.fromString(account)) {
            greeting = "Welcome, business user!";
        }

        return Mono.just(greeting);
    }
}
